from typing import List

Vector = List[float]
StringVector = List[str]
