from IPython.display import HTML


def init():
    return HTML("""The lib was successfully loaded 👍<script src='js/dd-graphs.js'/>""")
